<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Mamma Maria's Pizzeria E-Commerce2012</title>

<meta name="keywords" content="free website templates, CSS layout, Pizza Company Website, HTML CSS" />

<meta name="description" content="Pizza Company Website - free CSS website template, Free HTML CSS Layout" />

<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 16px;
	font-weight: bold;
}
-->
</style>
</head>
<body>
<div id="templatemo_container">
  <div id="templatemo_header_section"> </div>
  <div id="templatemo_menu_bg">
    <div id="templatemo_menu">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="aboutus.php"  class="current">About Us</a></li>
		<li><a href="contact.php">Contact Us</a></li>
        <li><a href="product.php">Product</a></li>
        <li><a href="loginindex.php">Order Now! </a></li>
        <li><a href="franchise.php">Franchise</a></li>
      </ul>
    </div>
  </div>
  <div id="templatemo_header_pizza"> </div>
  <div id="templatemo_content">
    <div id="templatemo_content_left1">
      <div class="text" style="color:#000000">
	    <div align="center" class="style1">THE PIZZA STORY</div>
        
		<div align="justify">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The pizza creator’s idea was to come up with an authentic thin crunchy Italiano pizza crust with flavors that would suit the taste of the Filipino.<br />
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The first branch MAMMA MARIA’S PIZZA was opened in Bacolod City, in December of 2005. It was an immediate success, five more branches were opened in 2006, to serve the thousands of pizza patriots who ordered their favorite pizza flavors.<br />
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MAMMA MARIA’S PIZZA has become a big challenge of all other international and local pizza brands operating in the Philippines.MAMMA MARIA’S PIZZA will soon be in your neighborhood to serve you the biggest & tastiest Pizza in the Philippines.<br />
 
	    </div>
		<div align="center" class="style1">WHY MAMMA MARIA’S PIZZA</div>
		<div align="justify">
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The special dough mix of the pizza is rolled right in front of the customer so they can see the entire process of the preparation. The best quality toppings are used to give the customer the famous original MAMMA MARIA’S PIZZA.<br />
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The affordable prices along with its quality flavors have made the MAMMA MARIA’S PIZZA brand the success it is today.
		  It is undoubtedly the favorite party food and the food habit of families and corporate business groups.<br />
		  Now MAMMA MARIA’S PIZZA will invade the other parts of the Philippines.<br />
		</div>
		<strong>
	  <div align="center">Take a “TASTE” bite of an EXCELLENT business opportunity</div></strong></div>
      
    </div>
    
  </div>

</div>
<div id="templatemo_footer">
    	<div class="top"></div>
        <div class="middle">
    Copyright © Mamma Maria's Pizzeria E-Commerce2012</div>
        <div class="button"></div>
<div>
</div>
</body>

</html>