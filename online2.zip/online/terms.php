<div style="width:300px; height:400px; color:#000000;">
  <div align="justify">
  <br ><strong>* 30 minutes guarantee applies up to the village/subdivision or building lobby,receipionist or basement.</strong></br>
    
   <br /><strong>*  Gurantee applies to a single receipt delivery transaction/minimum of 2 Pizza.</strong></br>
    
    <br /><strong>* Guaranteed time maybe suspended depending on the weather conditions for the safety of our delivery riders.</strong></br>

 <br /><strong>* Plus 20 pesos Standard Delivery Cost! Guarranted Hot!!!.</strong></br>
    
   <br /><strong>* All prices quoted are in Philippine pesos. Price and availability information is subject to change without notice.</strong></br>
    
   <br /><strong>* Mode of payment are as follows:customers with paypal account can pay through paypal otherwise Cash on Delivery(COD).</strong></br>
  </div>
</div>
