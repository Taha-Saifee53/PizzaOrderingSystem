<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
ob_start();
mysql_connect("localhost","root","");	//connecting to the database
mysql_select_db("cagc"); #Selecting the database.
?>
<?php
$id=$_GET['eid'];
$src="SELECT * FROM `tab1` WHERE `id`=".$id;
$rs=mysql_query($src);
$row=mysql_fetch_array($rs);
?>
<div style="width:500px; height:300px; background:#FF6; margin:0 auto; font-family:Arial, Helvetica, sans-serif;">
<h1 style="margin:0; padding:0; text-align:center;">Modify Records</h1>
<form name="frm" method="post">
<table cellpadding="10">
<tr>
	<td>Enter your name</td>
    <td><input type="text" name="name" required value="<?php echo $row['name'] ?>"></td>
</tr>
<tr>
	<td>Enter your Email</td>
    <td><input type="email" name="email" required value="<?php echo $row['email'] ?>"></td>
</tr>
<tr>
	<td>Enter your Pasword</td>
    <td><input type="password" name="pwd" required value="<?php echo $row['pwd'] ?>"></td>
</tr>
<tr>
	<td>&nbsp;</td>
    <td><input type="submit" name="ok" value="Save Changes"></td>
</tr>
</table>
</form>
<a href="retrieve.php"><button>View Records</button></a>
<?php
if(isset($_POST['ok']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$pwd=$_POST['pwd'];
	
	$upd="UPDATE `tab1` SET `name`='$name',`email`='$email',`pwd`='$pwd' WHERE `id`=".$id;
	$res=mysql_query($upd);
	if($res==1)
	{
		echo "Update sucessfull";
	}
	else
	{
		echo "Update failed";
	}
}
?>
</div>
</body>
</html>