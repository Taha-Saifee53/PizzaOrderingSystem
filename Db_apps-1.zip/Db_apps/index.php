<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
ob_start();
mysql_connect("localhost","root","");	//connecting to the database
mysql_select_db("cagc"); #Selecting the database.
?>
<div style="width:500px; height:300px; background:#FF6; margin:0 auto; font-family:Arial, Helvetica, sans-serif;">
<h1 style="margin:0; padding:0; text-align:center;">Free User Registration</h1>
<form name="frm" method="post">
<table cellpadding="10">
<tr>
	<td>Enter your name</td>
    <td><input type="text" name="name" required></td>
</tr>
<tr>
	<td>Enter your Email</td>
    <td><input type="email" name="email" required></td>
</tr>
<tr>
	<td>Enter your Pasword</td>
    <td><input type="password" name="pwd" required></td>
</tr>
<tr>
	<td>&nbsp;</td>
    <td><input type="submit" name="ok" value="Register"></td>
</tr>
</table>
</form>
<a href="retrieve.php"><button>View Records</button></a>
<?php
if(isset($_POST['ok']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$pwd=$_POST['pwd'];
	//echo "Your information is ".$name."  ".$email."  ".$pwd;
	$sql="INSERT INTO `tab1` (`name`,`email`,`pwd`) VALUES ('$name','$email','$pwd')";
	$res=mysql_query($sql);
	if($res==1)
	{
		echo "Registration sucessfull";
	}
	else
	{
		echo "Registration failed";
	}
}
?>
</div>
</body>
</html>