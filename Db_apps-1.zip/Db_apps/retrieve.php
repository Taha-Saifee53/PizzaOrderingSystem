<?php
ob_start();
mysql_connect("localhost","root","");	//connecting to the database
mysql_select_db("cagc"); #Selecting the database.
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Data Retrieve</title>
</head>

<body>
<?php
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$del="DELETE FROM `tab1` WHERE `id`=".$id;
	$res=mysql_query($del);
	if($res==1)
	{
		echo "Record has been deleted";
	}
	else
	{
		echo "Sorry record not delete";
	}
}
?>
<?php
$src="SELECT * FROM `tab1`";
$rs=mysql_query($src);
if(mysql_num_rows($rs)>0)
{
	?>
    <table cellpadding="5" cellspacing="0" border="1">
    <thead>
    	<tr>
        	<th>Sl No.</th><th>Name</th><th>Email</th><th>Password</th><th>Update</th><th>Delete</th>
        </tr>
    </thead>
	<?php
	$sl=1;
	while($row=mysql_fetch_array($rs))
	{
		?>
        <tr>
        	<td><?php echo $sl ?></td>
            <td><?php echo $row['name'] ?></td>
            <td><?php echo $row['email'] ?></td>
            <td><?php echo $row['pwd'] ?></td>
            <td><a href="update.php?eid=<?php echo $row['id'] ?>"><img src="img/update.png"></a></td>
            <td><a href="retrieve.php?id=<?php echo $row['id'] ?>"><img src="img/delete.png"></a></td>
        </tr>
		<?php
		$sl++;
	}
	?>
    </table>
	<?php
}
else
{
	echo "No records found";
}
?>
</body>
</html>